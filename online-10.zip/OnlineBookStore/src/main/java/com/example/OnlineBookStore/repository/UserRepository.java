package com.example.OnlineBookStore.repository;


//import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.OnlineBookStore.model.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {
	
	@Query("from User where email=?1")
	public User findByEMAIL(String user_email);
	
	@Query("from User where email=?1 and pass=?2")
	public User findByUsernamePassword(String username, String password);
	
}
