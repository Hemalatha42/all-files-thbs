package com.example.OnlineBookStore.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.example.OnlineBookStore.model.Course;

public interface CourseRepository extends CrudRepository<Course, Integer>{
	
	@Query("from Course where Category=?1")
	public List<Course> findAllByCategory(String category);
	
	@Query("from Course where id=?1")
	public Course findCourseById(int id);
	
}
