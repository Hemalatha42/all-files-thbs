package com.example.OnlineBookStore.controller;

import javax.servlet.http.HttpSession;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.OnlineBookStore.model.Category;
import com.example.OnlineBookStore.model.Course;
import com.example.OnlineBookStore.repository.CategoryRepo;
import com.example.OnlineBookStore.repository.CourseRepository;



@Repository
@Controller
public class CourseController {
	
	@Autowired
	CourseRepository adrep;
	
	@Autowired
	CategoryRepo catrepo;
	
	@PostMapping(value="/AddCourse")
	public String aadco(@ModelAttribute Course course, HttpSession session) {
		adrep.save(course);
		return "/admin_home";
	}
	@GetMapping(value="/AddCourse")
	public String adco(@ModelAttribute Course course, HttpSession session) {
		List<Category> categ=(List<Category>) catrepo.findAll();
		session.setAttribute("List", categ);
		return "/AddCourse";
	}
	
	@GetMapping(value = "/avail")
	public String allcou(HttpSession session) {
		List<Course> list=(List<Course>) adrep.findAll();
		System.out.println(list);
		session.setAttribute("useritem", list);
		return "/availcourse";
	}
	
	@GetMapping("/deleteCourse/{id}")
	public String deleteNotes(@PathVariable int id,HttpSession session) {
		
		Optional<Course> notes=adrep.findById(id);
		if(notes!=null)
		{
			adrep.delete(notes.get());
			//session.setAttribute("delete", "Course Deleted Successfully");
		}
		
		return "/admin_home";
	}
	
	@GetMapping("/editCourse/{id}")
	public String upd(@PathVariable int id, Model m) {
		//List<Course> notes=(List<Course>)adrep.findById(id);
		Course notes=adrep.findCourseById(id);
		//List<Course> list=(List<Course>) adrep.findById(id);
		m.addAttribute("note", notes);
		return "/editCourse";
	}
	
	@GetMapping("/AddCategory")
	public String addcat(HttpSession session) {
		return "/AddCategory";
		
	}
	
	@PostMapping("/catadd")
	public String cate(HttpSession session, Category cat){
		System.out.println(cat);
		catrepo.save(cat);
		List<Category> categ=(List<Category>) catrepo.findAll();
		session.setAttribute("List", categ);
		return "/AddCourse";
	}
	
	@PostMapping("/editCourse/updateCourse")
	public String updateNotes(@ModelAttribute Course notes, HttpSession session) {
		
		adrep.deleteById(notes.getId());
		System.out.println(notes.getId());
		Course updateNotes = adrep.save(notes);

		if (updateNotes != null) {
			session.setAttribute("msg", "Course Updated Sucessfully");
		} else {
			session.setAttribute("msg", "Something wrong on server");
		}

		System.out.println(notes);

		return "redirect:/avail";
	}
	
	
	
}
