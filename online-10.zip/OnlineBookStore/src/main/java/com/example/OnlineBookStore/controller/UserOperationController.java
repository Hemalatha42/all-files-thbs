package com.example.OnlineBookStore.controller;

import java.util.List;
//import java.util.Optional;
import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.OnlineBookStore.model.Course;
import com.example.OnlineBookStore.repository.CategoryRepo;
import com.example.OnlineBookStore.repository.CheckoutRepository;
import com.example.OnlineBookStore.repository.CourseRepository;
//import com.example.OnlineBookStore.email.RestController;//*
import com.example.OnlineBookStore.model.Category;
import com.example.OnlineBookStore.model.Checkout;

@Repository
@Controller
public class UserOperationController {
	
	@Autowired
	CourseRepository adrep;
	
	@Autowired
	CategoryRepo catrepo;
	
	@Autowired
	CheckoutRepository CheckoutRepository;
	
	@GetMapping(value = "/availcour")
	public String avail(HttpSession session, @RequestParam("Category") String Category) {
		
			System.out.println(Category.toLowerCase());
			List<Course> list=(List<Course>) adrep.findAllByCategory(Category);
			System.out.println(list);
			
			List<Category> categ=(List<Category>) catrepo.findAll();
			session.setAttribute("List", categ);
			
			session.setAttribute("useritem", list);
			session.setAttribute("Category", Category);
		
		return "/user_course";
	}
	
	@GetMapping(value="/getallcor")
	public String allco(HttpSession session) {
		List<Course> list=(List<Course>) adrep.findAll();
		System.out.println(list);
		List<Category> categ=(List<Category>) catrepo.findAll();
		session.setAttribute("List", categ);
		
		session.setAttribute("useritem", list);
		session.setAttribute("Category", "All");
		return "/user_course";
	}
	
	@GetMapping(value = "/buycourse/{id}")
	public String buy(@PathVariable int id,HttpSession session) {
		Course course = adrep.findCourseById(id);
		session.setAttribute("course_name", course.getName());
		return "/Checkout";
		
	}
	
	@GetMapping(value = "/buyfullstack")
	public String buyfull(HttpSession session) {
		
		session.setAttribute("course_name", "FullStack");
		return "/Checkout";
		
	}
	
	@GetMapping("/Checkout")
	public ModelAndView view1() {
		
		
		return new ModelAndView("Checkout");
	}
	
	@GetMapping("/FullStack")
	public String fullstack() {
		
		return "/FullStack";
	}
	
	@PostMapping("/Checkout1")
	public ModelAndView checkoutform(Checkout Checkout) {
	
		CheckoutRepository.save(Checkout);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		mv.addObject("success", "You bought the course!");
		mv.addObject("click","Click here to know more!");
		mv.addObject("email",Checkout.getEmail());
		return mv;
	}
}
