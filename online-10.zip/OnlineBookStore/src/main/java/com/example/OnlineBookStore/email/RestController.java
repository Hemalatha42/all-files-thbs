package com.example.OnlineBookStore.email;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@org.springframework.web.bind.annotation.RestController

public class RestController {
     
    @Autowired
    JavaMailSender javaMailSender;
     
     @RequestMapping(value="/sendEmail/{email}", method = RequestMethod.GET)
        public ModelAndView helloSpringBoot(@PathVariable String email){
              
         SimpleMailMessage message = new SimpleMailMessage();
             
            message.setFrom("saisanthoshrao25@gmail.com");
            message.setTo(email); //hemakempaiah1998
            message.setSubject("Welcome to R-Company");
            message.setText("Hi Applicant!\r\n"
            		+ "\r\n"
            		+ "Congratulations!\r\n"
            		+ "\r\n"
            		+ "You’ve successfully completed registration for our Course. Your registration is confirmed.\r\n"
            		+ "\r\n"
            		+ "Below is a list of forms completed as well as your balance.\r\n"
            		+ "\r\n"
            		+ "Any form in red needs to be completed and your payment balance should be paid no later than Session start date.\r\n"
            		+ "\r\n"
            		+ "If you’d like to review your registration forms or view or make a payment, you can do so on your dashboard. Log in with the email you received this message at.\r\n"
            		+ "\r\n"
            		+ "ACCESS YOUR DASHBOARD\r\n"
            		+ "\r\n"
            		+ "If you have any questions or concerns, feel free to contact me at email@r_company.com or 222-222-2222.\r\n"
            		+ "\r\n"
            		+ "Best,\r\n"
            		+ "Your R-Company Team");
             
            javaMailSender.send(message);
             
            System.out.println("Mail successfully sent..");
            ModelAndView mv = new ModelAndView();
            mv.setViewName("sendEmail");
             
            return mv;
        }
 
}
